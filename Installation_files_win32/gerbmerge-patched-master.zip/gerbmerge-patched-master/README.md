gerbmerge-patched
=================

Contains some patches to the gerbmerge program, from http://ruggedcircuits.com/gerbmerge/